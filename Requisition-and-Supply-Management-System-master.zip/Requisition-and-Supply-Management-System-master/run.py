from App import app

#b'$2b$12$U0Cx0X5x.fxpOTZGG8JAPumts3m5EDWvXScWguYsqBgx4/E8q2VF.'

if __name__ == '__main__':
    app.run(debug = True )